<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.io.*" %>
<%@ page import="java.util.*" %>
<%!
private String esc(String s) {
    if (s == null) return "";
    return s.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&#39;");
}

private java.util.List<String> readLastLines(File file, int maxLines) {
    LinkedList<String> lines = new LinkedList<String>();
    if (file == null || !file.exists()) return lines;
    BufferedReader br = null;
    try {
        br = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
        String line;
        while ((line = br.readLine()) != null) {
            lines.add(line);
            if (lines.size() > maxLines) lines.removeFirst();
        }
    } catch (Exception ignored) {
    } finally {
        try { if (br != null) br.close(); } catch (Exception ignored) {}
    }
    return lines;
}
%>
<%
application.log("User visited upload page");
File auditFile = new File(new File(application.getRealPath("/"), "WEB-INF/logs"), "file-actions.log");
java.util.List<String> auditLines = readLastLines(auditFile, 30);
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Upload Document - SecureDocs</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="layout">
    <aside class="sidebar">
        <div class="brand"><div class="logo">SD</div><div><h2>SecureDocs</h2><p>Internal Document Portal</p></div></div>
        <nav>
            <a href="index.jsp">Dashboard</a>
            <a class="active" href="upload.jsp">Upload Document</a>
            <a href="files.jsp">Document Library</a>
            <a href="status.jsp">Server Status</a>
        </nav>
        <div class="lab-badge">LAB ENVIRONMENT</div>
    </aside>

    <main class="main">
        <header class="topbar"><div><h1>Upload Document</h1><p>Upload internal documents to the lab portal</p></div></header>

        <section class="panel upload-panel">
            <form action="upload-handler.jsp" method="post" enctype="multipart/form-data" class="upload-box">
                <div class="upload-icon">↑</div>
                <h2>Select a file to upload</h2>
                <p>Recommended for testing: .txt, .pdf, .docx, .png</p>
                <input type="file" name="file" required>
                <button class="btn primary" type="submit">Upload Document</button>
            </form>
            <div class="notice">This feature stores files inside the webapp <code>/uploads</code> directory for lab testing.</div>
        </section>

        <section class="panel log-panel">
            <div class="section-title-row">
                <div>
                    <h2>Live File Action Log</h2>
                    <p>Recent upload/delete events are shown here.</p>
                </div>
                <a class="btn small" href="upload.jsp">Refresh Log</a>
            </div>
            <pre class="log-box"><% if (auditLines.size() == 0) { %>No file action logs yet.<% } else { for (String line : auditLines) { %><%= esc(line) %>
<% }} %></pre>
        </section>
    </main>
</div>
</body>
</html>
