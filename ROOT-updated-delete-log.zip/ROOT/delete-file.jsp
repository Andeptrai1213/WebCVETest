<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.io.*" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%@ page import="java.util.Date" %>
<%@ page import="javax.servlet.ServletContext" %>
<%@ page import="javax.servlet.http.HttpServletRequest" %>
<%!
private String esc(String s) {
    if (s == null) return "";
    return s.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&#39;");
}

private void writeAuditLog(ServletContext application, HttpServletRequest request, String action, String status, String fileName) {
    FileWriter fw = null;
    try {
        File logDir = new File(application.getRealPath("/"), "WEB-INF/logs");
        if (!logDir.exists()) logDir.mkdirs();
        File logFile = new File(logDir, "file-actions.log");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String ip = request.getRemoteAddr();
        fw = new FileWriter(logFile, true);
        fw.write(sdf.format(new Date()) + " | " + ip + " | " + action + " | " + status + " | " + fileName + "\n");
    } catch (Exception e) {
        application.log("Could not write audit log", e);
    } finally {
        try { if (fw != null) fw.close(); } catch (Exception ignored) {}
    }
}
%>
<%
request.setCharacterEncoding("UTF-8");
String fileName = request.getParameter("file");
String message;
String status;

if (fileName == null || !fileName.matches("[a-zA-Z0-9._-]+")) {
    message = "Invalid file name";
    status = "FAILED_INVALID_NAME";
    writeAuditLog(application, request, "DELETE", status, String.valueOf(fileName));
} else {
    File uploadDir = new File(application.getRealPath("/"), "uploads");
    File target = new File(uploadDir, fileName);
    String uploadPath = uploadDir.getCanonicalPath();
    String targetPath = target.getCanonicalPath();

    if (!targetPath.startsWith(uploadPath + File.separator)) {
        message = "Delete blocked";
        status = "FAILED_PATH_TRAVERSAL";
    } else if (!target.exists() || !target.isFile()) {
        message = "File not found";
        status = "FAILED_NOT_FOUND";
    } else if (target.delete()) {
        message = "File deleted successfully";
        status = "SUCCESS";
    } else {
        message = "Delete failed";
        status = "FAILED_DELETE_ERROR";
    }
    writeAuditLog(application, request, "DELETE", status, fileName);
}
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Result - SecureDocs</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="center-page">
    <div class="result-card">
        <div class="result-icon">!</div>
        <h1><%= esc(message) %></h1>
        <p>File:</p>
        <code><%= esc(fileName) %></code>
        <div class="actions">
            <a class="btn primary" href="files.jsp">Back to Documents</a>
            <a class="btn" href="upload.jsp">View Upload Log</a>
        </div>
    </div>
</div>
</body>
</html>
