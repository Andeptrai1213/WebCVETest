SecureDocs Test CVE WebApp

Deploy:
1. Extract this zip.
2. Copy the extracted folder into apache-tomcat-9.0.97/webapps/testcve
3. Start Tomcat.
4. Open http://localhost:8080/testcve/

Pages:
- index.jsp
- upload.jsp
- upload-handler.jsp
- files.jsp
- status.jsp

Use only in an isolated lab VM.

## Updated features

- Added Delete button in Document Library.
- Added `delete-file.jsp` for safe file deletion inside `/uploads`.
- Added audit log file at `WEB-INF/logs/file-actions.log`.
- Upload and delete actions are logged with timestamp, client IP, action, status, and file name.
- Upload page now shows recent file action logs directly in the browser.
